import { createContext } from "react";

const CurrentUserContext = createContext();

export default CurrentUserContext;
