# movies-explorer-frontend

Сылка на макет: https://disk.yandex.ru/d/YMSS7dAtH9DJXQ

Сылка на проект: https://morjello.movies.nomoredom.nomoreparties.sbs

Ссылка на api: https://api.morjello.movies.nomoredomains.monster

Публичный IP: 51.250.85.205

Ссылка на пул реквест: https://github.com/Morjello/movies-explorer-frontend/pull/2
