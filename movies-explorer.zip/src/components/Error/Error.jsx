const Error = ({ errorMessage }) => {
  return <p className="error">{errorMessage}</p>;
};

export default Error;
